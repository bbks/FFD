import React, { useState } from "react";
import { Button } from "../../../../components/ui/button";
import { Input } from "../../../../components/ui/input";
import { Label } from "../../../../components/ui/label";
import {
  RadioGroup,
  RadioGroupItem,
} from "../../../../components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../../../../components/ui/select";

interface FormField {
  id: string;
  label: string;
  type: string;
  options?: string[];
  value: string;
  error?: string;
  suffix?: string;
}

interface ActivityLevelMultiplier {
  [key: string]: number;
}

export const CalorieCalculatorSection = (): JSX.Element => {
  const [units, setUnits] = useState("imperial");
  const [focusedField, setFocusedField] = useState<string | null>(null);
  const [calculatedCalories, setCalculatedCalories] = useState<number | null>(null);

  const activityLevelMultipliers: ActivityLevelMultiplier = {
    sedentary: 1.2,
    light: 1.375,
    moderate: 1.55,
    active: 1.725,
    "very active": 1.9,
  };

  const [formFields, setFormFields] = useState<FormField[]>([
    { 
      id: "age", 
      label: "What is your age?", 
      type: "input",
      value: "",
      suffix: "years"
    },
    {
      id: "sex",
      label: "What is your sex at birth?",
      type: "select",
      options: ["Male", "Female"],
      value: ""
    },
    { 
      id: "height", 
      label: "What is your height?", 
      type: "input",
      value: "",
      suffix: units === "imperial" ? "inches" : "cm"
    },
    {
      id: "activity",
      label: "What is your activity level?",
      type: "select",
      options: ["Sedentary", "Light", "Moderate", "Active", "Very Active"],
      value: ""
    },
    {
      id: "currentWeight",
      label: "What is your current weight?",
      type: "input",
      value: "",
      suffix: units === "imperial" ? "lbs" : "kg"
    },
    { 
      id: "goalWeight", 
      label: "What is your goal weight?", 
      type: "input",
      value: "",
      suffix: units === "imperial" ? "lbs" : "kg"
    },
  ]);

  const handleInputChange = (fieldId: string, value: string) => {
    setFormFields(fields =>
      fields.map(field =>
        field.id === fieldId
          ? {
              ...field,
              value,
              error: validateField(fieldId, value)
            }
          : field
      )
    );
  };

  const validateField = (fieldId: string, value: string): string | undefined => {
    if (!value) return undefined;

    switch (fieldId) {
      case "age":
        const age = parseInt(value);
        if (isNaN(age) || age < 0 || age > 120) {
          return "Please enter a valid age between 0 and 120";
        }
        break;
      case "height":
        const height = parseFloat(value);
        const maxHeight = units === "imperial" ? 108 : 275;
        if (isNaN(height) || height <= 0 || height > maxHeight) {
          return `Please enter a valid height between 0 and ${maxHeight} ${units === "imperial" ? "inches" : "cm"}`;
        }
        break;
      case "currentWeight":
      case "goalWeight":
        const weight = parseFloat(value);
        const maxWeight = units === "imperial" ? 1000 : 453.6;
        if (isNaN(weight) || weight <= 0 || weight > maxWeight) {
          return `Please enter a valid weight between 0 and ${maxWeight} ${units === "imperial" ? "lbs" : "kg"}`;
        }
        break;
    }
    return undefined;
  };

  const convertToMetric = (value: number, type: 'weight' | 'height'): number => {
    if (units === 'metric') return value;
    return type === 'weight' ? value * 0.453592 : value * 2.54;
  };

  const calculateCalories = () => {
    const getFieldValue = (id: string): number => 
      parseFloat(formFields.find(f => f.id === id)?.value || "0");

    const age = getFieldValue("age");
    const height = convertToMetric(getFieldValue("height"), 'height');
    const currentWeight = convertToMetric(getFieldValue("currentWeight"), 'weight');
    const goalWeight = convertToMetric(getFieldValue("goalWeight"), 'weight');
    const sex = formFields.find(f => f.id === "sex")?.value.toLowerCase() || "";
    const activityLevel = formFields.find(f => f.id === "activity")?.value.toLowerCase() || "sedentary";

    const bmr = (10 * currentWeight) + (6.25 * height) - (5 * age) + (sex === "male" ? 5 : -161);
    let calories = Math.round(bmr * activityLevelMultipliers[activityLevel]);

    if (goalWeight < currentWeight) {
      calories -= 500;
    } else if (goalWeight > currentWeight) {
      calories += 500;
    }

    setCalculatedCalories(calories);
  };

  const resetCalculator = () => {
    setFormFields(fields => 
      fields.map(field => ({ ...field, value: "", error: undefined }))
    );
    setCalculatedCalories(null);
  };

  const handleUnitsChange = (newUnits: string) => {
    setUnits(newUnits);
    setFormFields(fields =>
      fields.map(field => {
        if (field.suffix && field.id !== "age") {
          return {
            ...field,
            suffix: field.id === "height" 
              ? newUnits === "imperial" ? "inches" : "cm"
              : newUnits === "imperial" ? "lbs" : "kg",
            value: ""
          };
        }
        return field;
      })
    );
  };

  const textStyles = "text-[18px] font-semibold text-[#161616]";
  const commonInputStyles = "h-10 px-4 bg-white rounded-lg";

  return (
    <div className="flex flex-wrap gap-4">
      {/* Form Section */}
      <div className="flex flex-col w-full md:w-[329px] gap-8 pb-8">
        {/* Units Selection */}
        <div className="flex flex-col gap-2 w-full rounded-lg">
          <Label className="font-normal text-[#161616] text-base">
            Units you prefer
          </Label>

          <RadioGroup
            defaultValue="imperial"
            className="flex gap-6"
            value={units}
            onValueChange={handleUnitsChange}
          >
            <div className="flex items-center">
              <RadioGroupItem
                value="imperial"
                id="imperial"
                className="mr-2"
              />
              <Label
                htmlFor="imperial"
                className="text-[18px] font-bold text-[#161616]"
              >
                Imperial
              </Label>
            </div>

            <div className="flex items-center">
              <RadioGroupItem value="metric" id="metric" className="mr-2" />
              <Label
                htmlFor="metric"
                className="text-[18px] font-bold text-[#161616]"
              >
                Metric
              </Label>
            </div>
          </RadioGroup>
        </div>

        <div className="flex flex-col gap-4 w-full">
          {/* Form Fields */}
          {formFields.map((field) => (
            <div
              key={field.id}
              className="flex flex-col gap-2 w-full rounded-lg"
            >
              <Label 
                className={`font-['SF_Pro-Regular',Helvetica] text-[13px] text-[#161616] opacity-80 transition-opacity ${
                  field.value || focusedField === field.id || field.error ? 'opacity-80' : 'opacity-0'
                }`}
              >
                {field.error || field.label}
              </Label>

              {field.type === "input" ? (
                <div className="relative">
                  <Input
                    placeholder={focusedField === field.id ? "" : field.label}
                    value={field.value}
                    onChange={(e) => handleInputChange(field.id, e.target.value)}
                    onFocus={() => setFocusedField(field.id)}
                    onBlur={() => setFocusedField(null)}
                    className={`${commonInputStyles} ${textStyles} pr-20 placeholder:${textStyles} ${
                      field.error ? 'border-red-500' : ''
                    }`}
                  />
                  {field.suffix && (
                    <span className="absolute right-4 top-1/2 -translate-y-1/2 font-['SF_Pro-Regular',Helvetica] text-[13px] text-[#161616] opacity-60">
                      {field.suffix}
                    </span>
                  )}
                </div>
              ) : (
                <Select
                  value={field.value}
                  onValueChange={(value) => handleInputChange(field.id, value)}
                >
                  <SelectTrigger 
                    className={`${commonInputStyles} ${textStyles} justify-between [&>span]:${textStyles}`}
                    onFocus={() => setFocusedField(field.id)}
                    onBlur={() => setFocusedField(null)}
                  >
                    <SelectValue placeholder={field.label} />
                  </SelectTrigger>
                  <SelectContent>
                    {field.options?.map((option) => (
                      <SelectItem 
                        key={option} 
                        value={option.toLowerCase()}
                        className={textStyles}
                      >
                        {option}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>
          ))}
        </div>

        {/* Calculate Button and Results Section */}
        <div className="flex items-center gap-4">
          <Button
            className={`h-[52px] px-8 py-2 rounded-2xl font-['SF_Pro-Regular',Helvetica] font-normal text-xl transition-colors ${
              calculatedCalories
                ? 'bg-white hover:bg-gray-100 text-[#161616] border border-[#161616]'
                : 'bg-[#161616] hover:bg-[#2c2c2c] text-[#f5f1f1]'
            }`}
            disabled={formFields.some(field => !field.value || field.error)}
            onClick={calculatedCalories ? resetCalculator : calculateCalories}
          >
            {calculatedCalories ? "Recalculate" : "Calculate Calories"}
          </Button>

          {calculatedCalories && (
            <div className="flex items-center gap-2">
              <span className="font-['SF_Pro-Semibold',Helvetica] text-[28px] font-normal text-[#161616]">
                {calculatedCalories.toLocaleString()}
              </span>
              <span className="font-['SF_Pro-Regular',Helvetica] text-[13px] text-[#161616] opacity-60">
                kCal
              </span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};