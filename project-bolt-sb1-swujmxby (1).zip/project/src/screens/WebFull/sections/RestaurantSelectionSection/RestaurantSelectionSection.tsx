import React, { useState } from "react";
import { Button } from "../../../../components/ui/button";
import { Input } from "../../../../components/ui/input";
import { Label } from "../../../../components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../../../../components/ui/select";

interface RestaurantSelectionSectionProps {
  onFindItOutClick: () => void;
}

interface DietPlan {
  breakfast: { restaurant: string; items: string[] };
  lunch: { restaurant: string; items: string[] };
  dinner: { restaurant: string; items: string[] };
}

export const RestaurantSelectionSection = ({ onFindItOutClick }: RestaurantSelectionSectionProps): JSX.Element => {
  const [calorieIntake, setCalorieIntake] = useState<string>("");
  const [focusedField, setFocusedField] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [dietPlan, setDietPlan] = useState<DietPlan | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleCalorieChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/[^0-9]/g, '');
    setCalorieIntake(value);
    setError(null);
  };

  const calculateDiet = async () => {
    if (!calorieIntake || parseInt(calorieIntake) <= 0) {
      setError('Please enter a valid calorie amount');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch('https://fastfooddiet.app/api/v1/plan/quick', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          calories: parseInt(calorieIntake, 10)
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      setDietPlan(data);
    } catch (err) {
      setError('Failed to calculate diet plan. Please try again.');
      console.error('Error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const getMealEmoji = (mealType: string) => {
    switch (mealType.toLowerCase()) {
      case 'breakfast':
        return '🍳';
      case 'lunch':
        return '🥗';
      case 'dinner':
        return '🍽️';
      default:
        return '🍴';
    }
  };

  const renderMealPlan = () => {
    if (!dietPlan) return null;

    return (
      <div className="mt-8 space-y-6">
        {Object.entries(dietPlan).map(([meal, { restaurant, items }]) => (
          <div key={meal} className="bg-white p-6 rounded-lg shadow-sm">
            <h3 className="text-xl font-semibold mb-3">
              {getMealEmoji(meal)} {meal.charAt(0).toUpperCase() + meal.slice(1)} ({restaurant})
            </h3>
            <ul className="space-y-2">
              {items.map((item, index) => (
                <li key={index} className="text-gray-700">• {item}</li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    );
  };

  return (
    <section className="flex flex-col items-start gap-[60px] w-full">
      <div className="flex flex-col items-start gap-10 w-full">
        <div className="flex flex-col max-w-[647px] items-start gap-4 w-full">
          <h2 className="text-[24px] font-semibold text-black">
            What is your daily calorie intake?
          </h2>

          <div className="flex flex-col gap-4 w-full">
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 w-full">
              <div className="flex flex-col gap-2 w-full sm:w-[268px]">
                <div className="flex items-center justify-between px-4 py-3 bg-white rounded-lg h-[52px] w-full">
                  <Input
                    id="caloriesInput"
                    placeholder={focusedField ? "" : "Enter calories"}
                    value={calorieIntake}
                    onChange={handleCalorieChange}
                    onFocus={() => setFocusedField(true)}
                    onBlur={() => setFocusedField(false)}
                    className="border-none shadow-none focus-visible:ring-0 focus-visible:ring-offset-0 text-black text-base placeholder:text-black text-[18px]"
                  />
                  <span className="font-normal text-[#16161699] text-base">
                    kCal
                  </span>
                </div>
              </div>

              <div className="hidden sm:flex items-center justify-center w-[40px]">
                <span className="text-xl font-normal text-black">
                  →
                </span>
              </div>

              <Button 
                className="h-[52px] w-full sm:w-auto px-12 bg-black rounded-2xl font-normal text-white text-xl disabled:opacity-50 disabled:cursor-not-allowed"
                disabled={!calorieIntake || isLoading}
                onClick={calculateDiet}
              >
                {isLoading ? 'Calculating...' : 'Calculate my Diet'}
              </Button>
            </div>

            {error && (
              <p className="text-red-500 text-sm mt-2">{error}</p>
            )}

            <div id="recommendations" className="w-full">
              {renderMealPlan()}
            </div>

            <p className="text-[18px] font-semibold text-black">
              If you're unsure →{" "}
              <button 
                onClick={onFindItOutClick}
                className="underline cursor-pointer hover:text-[#161616cc] transition-colors"
              >
                Find it out
              </button>
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};