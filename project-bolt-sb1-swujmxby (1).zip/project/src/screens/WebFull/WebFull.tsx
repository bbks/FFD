import React, { useState } from "react";
import { CalorieCalculatorSection } from "./sections/CalorieCalculatorSection/CalorieCalculatorSection";
import { RestaurantSelectionSection } from "./sections/RestaurantSelectionSection/RestaurantSelectionSection";
import { Dialog, DialogContent, DialogTitle } from "../../components/ui/dialog";

export const WebFull = (): JSX.Element => {
  const [isCalculatorOpen, setIsCalculatorOpen] = useState(false);

  return (
    <div className="flex flex-col items-center w-full bg-[#f5f1f1] min-h-screen">
      {/* Header */}
      <header className="w-full bg-[#f5f1f1] pt-8 relative flex items-center justify-center min-h-[300px]">
        <div className="flex items-center gap-8 max-w-[1200px] w-full px-4">
          <div className="w-[478px] h-[207px]">
            <img
              src="/images/logoFFD.png"
              alt="Fast Food Diet"
              className="w-full h-full object-contain"
            />
          </div>
          <div className="flex flex-col">
            <span className="text-[48px] leading-[120%] font-[600] text-[#FF4F79] font-['Shippori_Mincho']">Love fast food</span>
            <span className="text-[48px] leading-[120%] font-[600] text-black font-['Shippori_Mincho']">but want to stay on</span>
            <span className="text-[48px] leading-[120%] font-[600] text-black font-['Shippori_Mincho']">track with your</span>
            <span className="text-[48px] leading-[120%] font-[600] text-black font-['Shippori_Mincho']">health goals?</span>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="flex flex-col w-full max-w-[1200px] gap-40 py-8 px-4">
        <RestaurantSelectionSection onFindItOutClick={() => setIsCalculatorOpen(true)} />
      </main>

      <Dialog open={isCalculatorOpen} onOpenChange={setIsCalculatorOpen}>
        <DialogContent className="max-w-[800px] max-h-[90vh] bg-[#f5f1f1] p-8 overflow-y-auto">
          <DialogTitle className="text-2xl font-bold mb-6">Calorie Calculator</DialogTitle>
          <CalorieCalculatorSection />
        </DialogContent>
      </Dialog>
    </div>
  );
}